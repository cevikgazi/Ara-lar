use anyhow::{Context, Result};
use procfs::net::TcpState;
use std::env;
use std::process::{exit, Command};

fn main() {
    if let Err(e) = run() {
        eprintln!("❌ Hata: {:#}", e);
        exit(1);
    }
}

fn run() -> Result<()> {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        let name = args.get(0).map(|s| s.as_str()).unwrap_or("killport");
        println!("Kullanım: {} <PORT>", name);
        println!("Örnek : {} 3005", name);
        return Ok(());
    }

    let port: u16 = args[1]
        .parse()
        .with_context(|| format!("'{}' geçerli bir port numarası değil. Lütfen 1-65535 arası bir sayı girin.", args[1]))?;

    if port == 0 {
        anyhow::bail!("Port numarası 0 olamaz.");
    }

    match kill_port(port)? {
        0 => println!("❌ {} portunda dinleyen process bulunamadı.", port),
        n => println!("✅ {} portundaki {} process sonlandırıldı.", port, n),
    }

    Ok(())
}

fn kill_port(port: u16) -> Result<usize> {
    let pids = find_listening_pids(port)?;

    if pids.is_empty() {
        return Ok(0);
    }

    let mut killed = 0;
    for pid in pids {
        let status = Command::new("kill")
            .arg("-9")
            .arg(pid.to_string())
            .status()
            .with_context(|| format!("PID {} sonlandırılırken 'kill' komutu çalıştırılamadı.", pid))?;

        if status.success() {
            println!("✅ PID {} (port {}) sonlandırıldı.", pid, port);
            killed += 1;
        } else {
            eprintln!(
                "⚠️  PID {} sonlandırılamadı (izin sorunu olabilir veya process zaten sonlanmış olabilir).",
                pid
            );
        }
    }
    Ok(killed)
}

fn find_listening_pids(target_port: u16) -> Result<Vec<i32>> {
    let mut pids = Vec::new();

    // TCP IPv4
    let tcp_entries = procfs::net::tcp().context("TCP IPv4 bağlantıları okunamadı (/proc/net/tcp)")?;
    for entry in tcp_entries {
        if entry.local_address.port() == target_port && entry.state == TcpState::Listen {
            pids.extend(find_pids_by_inode(entry.inode)?);
        }
    }

    // TCP IPv6
    if let Ok(tcp6_entries) = procfs::net::tcp6() {
        for entry in tcp6_entries {
            if entry.local_address.port() == target_port && entry.state == TcpState::Listen {
                pids.extend(find_pids_by_inode(entry.inode)?);
            }
        }
    }

    pids.sort_unstable();
    pids.dedup();
    Ok(pids)
}

fn find_pids_by_inode(target_inode: u64) -> Result<Vec<i32>> {
    let mut pids = Vec::new();

    let processes = procfs::process::all_processes().context("Sistem süreçleri listelenemedi (/proc)")?;
    for process_res in processes {
        // Flatten safely to avoid unwrap, but procfs all_processes returns an iterator of Result
        let process = match process_res {
            Ok(p) => p,
            Err(_) => continue,
        };

        let fds = match process.fd() {
            Ok(f) => f,
            Err(_) => continue,
        };

        for fd_res in fds {
            let fd = match fd_res {
                Ok(f) => f,
                Err(_) => continue,
            };

            if let procfs::process::FDTarget::Socket(inode) = fd.target {
                if inode == target_inode {
                    pids.push(process.pid);
                }
            }
        }
    }
    Ok(pids)
}
