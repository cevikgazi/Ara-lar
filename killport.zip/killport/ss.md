**✅ Tamam, Rust ile istediğin gibi tek binary yapıyoruz!**

Sadece `killport 3005` yazınca otomatik olarak o portu bulan ve `kill -9` ile sonlandıran bir CLI aracı olacak.

### Adım adım guide (sıfırdan):

1. **Yeni proje oluştur**
```bash
cargo new killport --bin
cd killport
```

2. **`src/main.rs` dosyasının içeriğini tamamen aşağıdaki kodla değiştir:**

```rust
use std::env;
use std::process::{Command, exit};

fn main() {
    let args: Vec<String> = env::args().collect();

    // Port girilmediyse yardım göster
    if args.len() != 2 {
        eprintln!("Kullanım: {} <PORT>", if args.is_empty() { "killport" } else { &args[0] });
        eprintln!("Örnek: {} 3005", if args.is_empty() { "killport" } else { &args[0] });
        exit(1);
    }

    // Port'u al ve kontrol et
    let port: u16 = match args[1].parse() {
        Ok(p) if p > 0 && p < 65536 => p,
        _ => {
            eprintln!("❌ Hata: Geçerli bir port numarası girin (1-65535)");
            exit(1);
        }
    };

    // lsof ile PID'leri bul (en temiz ve güvenilir yöntem)
    let output = match Command::new("lsof")
        .arg("-ti")
        .arg(format!(":{}", port))
        .output()
    {
        Ok(o) => o,
        Err(e) => {
            eprintln!("❌ lsof çalıştırılamadı: {}", e);
            eprintln!("   lsof yüklü değilse şu komutu çalıştırın:");
            eprintln!("   sudo apt install lsof    # Debian/Ubuntu");
            eprintln!("   sudo dnf install lsof    # Fedora");
            exit(1);
        }
    };

    let stdout = String::from_utf8_lossy(&output.stdout);
    let pids: Vec<&str> = stdout.lines().filter(|l| !l.trim().is_empty()).collect();

    if pids.is_empty() {
        println!("❌ {} portunda çalışan process bulunamadı.", port);
        exit(0);
    }

    // Bulunan tüm PID'leri kill et
    for pid_str in pids {
        let pid: u32 = match pid_str.parse() {
            Ok(p) => p,
            Err(_) => continue,
        };

        match Command::new("kill").arg("-9").arg(pid.to_string()).status() {
            Ok(status) if status.success() => {
                println!("✅ PID {} (port {}) sonlandırıldı.", pid, port);
            }
            Ok(_) => {
                eprintln!("⚠️  PID {} kill edilemedi (izin sorunu olabilir).", pid);
            }
            Err(e) => {
                eprintln!("❌ PID {} kill hatası: {}", pid, e);
            }
        }
    }
}
```

3. **Derle ve kullan**
```bash
cargo build --release
```

Derlenen binary:
```bash
./target/release/killport 3005
```

Sisteme global kurmak istersen:
```bash
sudo cp target/release/killport /usr/local/bin/
# Artık her yerden kullanabilirsin: killport 3005
```

### Ekstra istersen:
- Renkli çıktı + daha güzel argüman desteği (clap + colored) istiyorsan söyle, hemen eklerim.
- `lsof` yerine sadece `ss`/`netstat` ile yapan versiyon da yazabilirim (hiç ekstra program istemiyorsan).

Hazır!  
Şimdi `cargo build --release` yapıp dene.  
Herhangi bir sorun olursa buraya yapıştır, hemen düzeltirim. 🚀






✅ **Tamam, NixOS (ve diğer Linux sistemler) için external araçsız çözüm hazır!**

`lsof`, `ss`, `netstat`, `fuser` gibi **hiçbir harici programa** bağımlı değil.  
Tamamen Rust ile `/proc` dosyasisteminden okuyor → **tek binary**, hiçbir ekstra paket kurmana gerek yok.

### 1. Projeyi oluştur
```bash
cargo new killport --bin
cd killport
```

### 2. `Cargo.toml` dosyasını güncelle
```toml
[package]
name = "killport"
version = "0.1.0"
edition = "2021"

[dependencies]
procfs = "0.17"
```

### 3. `src/main.rs` dosyasının **tamamını** aşağıdaki kodla değiştir:

```rust
use std::env;
use std::process::exit;

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        let name = args.get(0).map(|s| s.as_str()).unwrap_or("killport");
        println!("Kullanım: {} <PORT>", name);
        println!("Örnek : {} 3005", name);
        exit(1);
    }

    let port: u16 = match args[1].parse() {
        Ok(p) if (1..=65535).contains(&p) => p,
        _ => {
            eprintln!("❌ Hata: Geçerli bir port numarası girin (1-65535)");
            exit(1);
        }
    };

    match kill_port(port) {
        Ok(0) => println!("❌ {} portunda dinleyen process bulunamadı.", port),
        Ok(n) => println!("✅ {} portundaki {} process sonlandırıldı.", port, n),
        Err(e) => eprintln!("❌ Hata: {}", e),
    }
}

fn kill_port(port: u16) -> Result<usize, String> {
    let pids = find_listening_pids(port);

    if pids.is_empty() {
        return Ok(0);
    }

    let mut killed = 0;
    for pid in pids {
        match std::process::Command::new("kill")
            .arg("-9")
            .arg(pid.to_string())
            .status()
        {
            Ok(status) if status.success() => {
                println!("✅ PID {} (port {}) sonlandırıldı.", pid, port);
                killed += 1;
            }
            _ => eprintln!("⚠️  PID {} sonlandırılamadı (izin sorunu olabilir).", pid),
        }
    }
    Ok(killed)
}

fn find_listening_pids(target_port: u16) -> Vec<i32> {
    let mut pids = Vec::new();

    // TCP IPv4
    if let Ok(entries) = procfs::net::tcp() {
        for entry in entries {
            if entry.local_port == target_port && entry.state == procfs::net::TcpState::Listen {
                if let Some(inode) = entry.inode {
                    pids.extend(find_pids_by_inode(inode));
                }
            }
        }
    }

    // TCP IPv6
    if let Ok(entries) = procfs::net::tcp6() {
        for entry in entries {
            if entry.local_port == target_port && entry.state == procfs::net::TcpState::Listen {
                if let Some(inode) = entry.inode {
                    pids.extend(find_pids_by_inode(inode));
                }
            }
        }
    }

    pids.sort_unstable();
    pids.dedup();
    pids
}

fn find_pids_by_inode(target_inode: u64) -> Vec<i32> {
    let mut pids = Vec::new();

    if let Ok(processes) = procfs::process::all_processes() {
        for process in processes.flatten() {
            if let Ok(fds) = process.fd() {
                for fd in fds {
                    if let procfs::process::FDTarget::Socket(inode) = fd.target {
                        if inode == target_inode {
                            pids.push(process.pid);
                        }
                    }
                }
            }
        }
    }
    pids
}
```

### 4. Derle ve kullan
```bash
cargo build --release
```

Derlenen binary:
```bash
./target/release/killport 3005
```

Sisteme kalıcı kurmak istersen:
```bash
sudo cp target/release/killport /usr/local/bin/
# Artık her yerden: killport 3005
```

### Ekstra bilgiler (NixOS’a özel)
- **Static binary** istiyorsan (hiçbir kütüphane bağımlılığı olmasın):
  ```bash
  cargo build --release --target x86_64-unknown-linux-musl
  ```
  (önce `musl` target kur: `nix-env -iA nixpkgs.musl`)

- UDP desteği de istersen söyle, hemen eklerim.

Şimdi `cargo build --release` yapıp dene.  
Herhangi bir hata alırsan terminal çıktısını buraya yapıştır, anında düzeltirim! 🚀





**✅ Devbox + NixOS için özel cevap:**

Kodumuz **zaten Devbox’ta sorunsuz çalışır**. Hiçbir ekstra paket ya da `lsof`/`ss`/`netstat` gerektirmez. Tamamen `/proc` üzerinden okur.

### Sudo konusu (en önemli kısım):
**Hayır, normalde sudo kullanmana gerek yok.**

- Devbox shell’inde ya da normal NixOS’ta 3005 portundaki process **senin kendi kullanıcı hesabınla** çalışır.
- Bu yüzden direkt `killport 3005` yazman yeterli olur.

Sadece şu durumlarda sudo gerekir:
- Process root ya da başka bir kullanıcıya aitse
- “Operation not permitted” hatası alırsan

O zaman şunu kullan:
```bash
sudo killport 3005
```

### Devbox’ta nasıl kullanacaksın (adım adım):

1. **Devbox shell’ini aç**
   ```bash
   devbox shell
   ```

2. **Binary’yi derle** (bir kere yapman yeterli)
   ```bash
   cargo build --release
   ```

3. **Test et**
   ```bash
   ./target/release/killport 3005
   ```

4. **Kalıcı olarak sisteme kur** (tüm devbox shell’lerinde ve normal terminalde çalışsın)
   ```bash
   mkdir -p ~/.local/bin
   cp target/release/killport ~/.local/bin/killport
   chmod +x ~/.local/bin/killport
   ```

   Artık her yerden sadece şunu yazman yeterli:
   ```bash
   killport 3005
   ```

**İpucu:** `~/.local/bin` zaten PATH’te olduğu için Devbox shell’lerinde de otomatik görünür.

Herhangi bir hata alırsan (özellikle “permission denied” veya procfs ile ilgili) terminaldeki tam çıktıyı buraya yapıştır, anında düzeltirim.

Hazırsan `devbox shell` açıp derleyebilirsin. 🚀





**✅ Tamam, istediğin gibi tek bir Bash script'i hazırladım!**

Bu script **her şeyi otomatik ve sırayla** yapacak:

1. Rust projesini oluşturacak  
2. `Cargo.toml` ve `main.rs` dosyalarını doğru kodla yazacak  
3. `cargo build --release` yapacak  
4. Binary’yi `~/.local/bin/killport` olarak kuracak  
5. Çalıştırılabilir yapacak  
6. Başarı mesajı verecek

---

### Nasıl kullanacaksın? (2 saniyede kurulum)

Devbox shell’ini açtıktan sonra terminale **aşağıdaki komutu tamamen kopyala-yapıştır** ve Enter’a bas:

```bash
cat > ~/install-killport.sh << 'EOF'
#!/usr/bin/env bash
set -e

echo "🚀 killport otomatik kurulumu başlıyor... (NixOS / Devbox uyumlu)"

# Cargo kontrolü
if ! command -v cargo >/dev/null 2>&1; then
  echo "❌ Cargo bulunamadı! Lütfen devbox shell içinde olduğundan emin ol."
  exit 1
fi

PROJECT_NAME="killport"
INSTALL_DIR="$HOME/.local/bin"
BINARY_NAME="killport"

# Proje klasörü oluştur veya varsa içine gir
if [ -d "$PROJECT_NAME" ]; then
  echo "📁 $PROJECT_NAME klasörü zaten var, güncelliyorum..."
  cd "$PROJECT_NAME"
else
  echo "📁 Yeni Rust projesi oluşturuluyor..."
  cargo new --bin "$PROJECT_NAME"
  cd "$PROJECT_NAME"
fi

# Cargo.toml yaz
cat > Cargo.toml << 'EOT'
[package]
name = "killport"
version = "0.1.0"
edition = "2021"
description = "Sadece port gir, process'i öldür"

[dependencies]
procfs = "0.17"
EOT

# src/main.rs yaz (tamamen external araçsız versiyon)
cat > src/main.rs << 'EOT'
use std::env;
use std::process::exit;

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() != 2 {
        let name = args.get(0).map(|s| s.as_str()).unwrap_or("killport");
        println!("Kullanım: {} <PORT>", name);
        println!("Örnek : {} 3005", name);
        exit(1);
    }

    let port: u16 = match args[1].parse() {
        Ok(p) if (1..=65535).contains(&p) => p,
        _ => {
            eprintln!("❌ Hata: Geçerli bir port numarası girin (1-65535)");
            exit(1);
        }
    };

    match kill_port(port) {
        Ok(0) => println!("❌ {} portunda dinleyen process bulunamadı.", port),
        Ok(n) => println!("✅ {} portundaki {} process sonlandırıldı.", port, n),
        Err(e) => eprintln!("❌ Hata: {}", e),
    }
}

fn kill_port(port: u16) -> Result<usize, String> {
    let pids = find_listening_pids(port);

    if pids.is_empty() {
        return Ok(0);
    }

    let mut killed = 0;
    for pid in pids {
        match std::process::Command::new("kill")
            .arg("-9")
            .arg(pid.to_string())
            .status()
        {
            Ok(status) if status.success() => {
                println!("✅ PID {} (port {}) sonlandırıldı.", pid, port);
                killed += 1;
            }
            _ => eprintln!("⚠️  PID {} sonlandırılamadı (izin sorunu olabilir).", pid),
        }
    }
    Ok(killed)
}

fn find_listening_pids(target_port: u16) -> Vec<i32> {
    let mut pids = Vec::new();

    if let Ok(entries) = procfs::net::tcp() {
        for entry in entries {
            if entry.local_port == target_port && entry.state == procfs::net::TcpState::Listen {
                if let Some(inode) = entry.inode {
                    pids.extend(find_pids_by_inode(inode));
                }
            }
        }
    }

    if let Ok(entries) = procfs::net::tcp6() {
        for entry in entries {
            if entry.local_port == target_port && entry.state == procfs::net::TcpState::Listen {
                if let Some(inode) = entry.inode {
                    pids.extend(find_pids_by_inode(inode));
                }
            }
        }
    }

    pids.sort_unstable();
    pids.dedup();
    pids
}

fn find_pids_by_inode(target_inode: u64) -> Vec<i32> {
    let mut pids = Vec::new();

    if let Ok(processes) = procfs::process::all_processes() {
        for process in processes.flatten() {
            if let Ok(fds) = process.fd() {
                for fd in fds {
                    if let procfs::process::FDTarget::Socket(inode) = fd.target {
                        if inode == target_inode {
                            pids.push(process.pid);
                        }
                    }
                }
            }
        }
    }
    pids
}
EOT

echo "📦 Derleniyor (ilk seferde biraz uzun sürebilir)..."
cargo build --release

# Binary’yi kalıcı yere kur
mkdir -p "$INSTALL_DIR"
cp "target/release/$BINARY_NAME" "$INSTALL_DIR/$BINARY_NAME"
chmod +x "$INSTALL_DIR/$BINARY_NAME"

echo ""
echo "✅ KURULUM TAMAMLANDI!"
echo "   Artık her yerden şu komutu kullanabilirsin:"
echo "   killport 3005"
echo ""
echo "   Test etmek için hemen dene: killport 3005"
EOF

chmod +x ~/install-killport.sh
~/install-killport.sh
```

---

Script bittikten sonra **test etmek için**:

```bash
killport 3005
```

Herhangi bir hata alırsan terminaldeki çıktıyı buraya yapıştır, hemen düzeltirim.  

Hazırsan yapıştır ve çalıştır! 🚀



**✅ Sorun anlaşıldı!**  

Bu hata NixOS + Devbox’ta **çok klasik** bir durum. Rust derlerken `cc` (linker) bulunamıyor çünkü Devbox shell’inde C derleyicisi (gcc) varsayılan olarak yüklü değil.

### Tek komutla düzeltelim (sırayla yap):

1. **gcc’yi Devbox’a ekle** (bir kere yapman yeterli)
```bash
devbox add gcc
```

2. **Devbox shell’ini yeniden başlat** (çok önemli!)
```bash
exit
devbox shell
```

3. **killport klasörüne gir** (script zaten oluşturmuştu)
```bash
cd ~/0fik/killport
```

4. **Tekrar derle** (şimdi sorunsuz çalışacak)
```bash
cargo build --release
```

5. **Kurulumu tamamla** (script’in kalan kısmını elle çalıştır)
```bash
mkdir -p ~/.local/bin
cp target/release/killport ~/.local/bin/killport
chmod +x ~/.local/bin/killport
```

6. **Test et**
```bash
killport 3005
```

---

**Hepsi bu kadar!**  
Yukarıdaki 1-2-3-4-5-6 adımlarını sırayla yap.  

Herhangi bir adımda yeni bir hata alırsan, terminaldeki çıktıyı olduğu gibi buraya yapıştır, anında devam edelim.

Hazırsan başla → `devbox add gcc` ile başla! 🚀


✅ **Tamam, anladım!**  

Bir sefer derleyeceksin → **tamamen static binary** olacak (hiçbir şeye bağımlı değil) → GitHub’a atacaksın → ömür boyu her Linux makinede (NixOS, Ubuntu, Devbox vs.) direkt indireyip kullanacaksın.

### 1. Devbox’ta static derleme ortamını kur (bir kere yap)

```bash
devbox add gcc musl
```

Sonra devbox shell’i yeniden başlat:

```bash
exit
devbox shell
```

### 2. Rust musl target’ını ekle

```bash
rustup target add x86_64-unknown-linux-musl
```

### 3. killport klasörüne gir ve static olarak derle

```bash
cd ~/0fik/killport          # (ya da projenin olduğu yer)
cargo build --release --target x86_64-unknown-linux-musl
```

Derleme bittiğinde binary şu yolda olacak:

**`target/x86_64-unknown-linux-musl/release/killport`**

Bu dosya **%100 static** ve portable.

### 4. Binary’yi GitHub Releases’e at (önerilen)

1. GitHub’da yeni bir repo oluştur (örnek: `killport`)
2. Releases → “Create a new release”  
3. Tag: `v0.1.0`  
4. Binary dosyasını sürükle-bırak (ya da `target/x86_64-unknown-linux-musl/release/killport` dosyasını yükle)
5. Release’i yayınla

### 5. Her yerde kullanmak için (tek komut)

İleride herhangi bir makinede şu komutla indirebilirsin:

```bash
curl -L https://github.com/kullanicin/killport/releases/latest/download/killport \
  -o /usr/local/bin/killport && chmod +x /usr/local/bin/killport
```

Sonra:

```bash
killport 3005
```

---

Şimdi **sırayla** yukarıdaki 1 → 2 → 3 adımlarını yap.  
Derleme bittikten sonra `ls target/x86_64-unknown-linux-musl/release/killport` yazıp binary’nin çıktığını gör.

Herhangi bir adımda hata alırsan terminal çıktısını buraya yapıştır, hemen devam edelim.

Hazırsan başla → `devbox add gcc musl` ile! 🚀
