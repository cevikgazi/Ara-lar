# 🚀 killport

Bilgisayarında bir portun (örneğin 3005) takılı kalması ve "Address already in use" hatası almaktan bıktın mı? Bu küçük araç, tek komutla o portu kullanan bütün programları bulur ve "infaz eder" (kapatır).

## 🤔 Bu nedir?

Bazen bir programı kapatırsın ama arka planda portu dinlemeye devam eder. Normalde terminalden 3-4 tane karmaşık komut yazarak PID bulup sonra onları `kill` etmen gerekir. **killport** ile sadece port numarasını yazarsın, o gerisini halleder.

## ✨ Özellikler

*   **Bağımsızdır:** Hiçbir şeye (lsof, netstat, ss vb.) ihtiyaç duymaz. Sadece kendi dosyasını indirip çalıştırman yeterli.
*   **Hızlıdır:** Rust ile yazıldı, anında sonuç verir.
*   **Hata Yapmaz:** Yanlış programı kapatmaz, sadece belirttiğin portu dinleyenleri hedefler.

## 🚀 Nasıl Kullanılır?

Kurulum falan gerekmez. Binary dosyasını indir ve terminalde şunu yaz:

```bash
killport 3005
```
*(3005 yerine hangi portu kapatmak istiyorsan onu yazabilirsin.)*

## 📥 Sıfır Bilgisayara Kurulum (Hızlı Yol)

Yeni bir bilgisayara geçtiğinde veya bu repoyu kullanmak istediğinde şu adımları izle:

1.  **Binary Dosyasını İndir:** GitHub'daki `Releases` kısmından senin sistemine uygun olan (Linux için genelde `killport`) dosyasını indir.
2.  **Çalıştırma İzni Ver:** Terminali aç ve dosyanın olduğu yere gidip şu komutu yaz:
    ```bash
    chmod +x killport
    ```
3.  **Sisteme Tanıt (Opsiyonel):** Her yerden kullanmak istersen dosyayı `/usr/local/bin` veya `~/.cargo/bin` içine kopyala:
    ```bash
    cp killport ~/.cargo/bin/
    ```

Artık her yerden `killport 8080` diyerek port temizleyebilirsin!

## 🛠️ Teknik Detay

Bu araç tamamen **static** olarak derlenmiştir. Yani içinde çalışması için gereken her şey (kütüphaneler vs.) bu tek bir dosyanın içindedir. Linux sistemlerde hiçbir ekstra paket kurmana gerek kalmadan doğrudan çalışır.

---
*Rust ile sevgiyle yapıldı. 🦀*
