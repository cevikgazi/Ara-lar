// src/error.rs - Gelişmiş Hata Yönetimi

use std::path::PathBuf;
use thiserror::Error;

#[derive(Error, Debug)]
pub enum AppError {
    // IO Errors
    #[error("IO Hatası: {source}")]
    Io {
        #[from]
        source: std::io::Error,
    },

    // Dosya Tarama Hataları
    #[error("Dosya Tarama Hatası: {source}")]
    Ignore {
        #[from]
        source: ignore::Error,
    },

    // Yol Hataları
    #[error("Geçersiz Dosya Yolu: {message}")]
    InvalidPath { message: String },

    // İzin Hataları
    #[error("Dosya İzni Reddedildi: {path}")]
    PermissionDenied { path: PathBuf },

    // Dosya Boyutu Hataları
    #[error("Dosya çok büyük: {path} ({size} MB > {limit} MB)")]
    FileTooLarge {
        path: PathBuf,
        size: u64,
        limit: u64,
    },

    // UTF-8 Hataları
    #[error("UTF-8 kodlama hatası: {file}")]
    InvalidUtf8 { file: String },

    // İptal Edilmiş İşlem
    #[error("İşlem iptal edildi ({processed}/{total} dosya işlendi)")]
    ProcessingInterrupted { processed: usize, total: usize },

    // Config Hataları
    #[error("Konfigürasyon hatası: {message}")]
    ConfigError { message: String },

    // Output Hataları
    #[error("Output dosyası yazılamadı: {path} ({reason})")]
    OutputWriteError { path: PathBuf, reason: String },

    // Parse Hataları
    #[error("Parse hatası ({file}): {message}")]
    ParseError { file: String, message: String },
}

// Context yönetimi için trait
pub trait ErrorContext<T> {
    fn context(self, msg: impl Into<String>) -> Result<T>;
    fn with_context(self, msg: impl Into<String>) -> Result<T>;
}

impl<T, E> ErrorContext<T> for std::result::Result<T, E>
where
    E: Into<AppError>,
{
    fn context(self, msg: impl Into<String>) -> Result<T> {
        self.map_err(|e| {
            let base_error = e.into();
            eprintln!("[ERROR] {}: {}", msg.into(), base_error);
            base_error
        })
    }

    fn with_context(self, msg: impl Into<String>) -> Result<T> {
        self.context(msg)
    }
}

pub type Result<T> = std::result::Result<T, AppError>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_error_display() {
        let err = AppError::InvalidPath {
            message: "Test error".to_string(),
        };
        assert!(err.to_string().contains("Geçersiz"));
    }

    #[test]
    fn test_file_too_large_error() {
        let err = AppError::FileTooLarge {
            path: PathBuf::from("/test/file.rs"),
            size: 2048,
            limit: 1024,
        };
        assert!(err.to_string().contains("çok büyük"));
    }
}
