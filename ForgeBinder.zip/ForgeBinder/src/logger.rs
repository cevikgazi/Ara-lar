use crate::error::{AppError, Result};
use std::fs::OpenOptions;
use std::io::Write;
use std::path::Path;
use std::sync::Mutex;

pub enum LogLevel {
    Debug,
    Info,
    Warn,
    Error,
}

impl std::fmt::Display for LogLevel {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            LogLevel::Debug => write!(f, "DEBUG"),
            LogLevel::Info => write!(f, "INFO"),
            LogLevel::Warn => write!(f, "WARN"),
            LogLevel::Error => write!(f, "ERROR"),
        }
    }
}

pub struct Logger {
    log_file: Mutex<Option<std::fs::File>>,
    console_output: Mutex<bool>,
}

impl Logger {
    pub fn new(log_path: Option<&Path>) -> Result<Self> {
        let file = if let Some(path) = log_path {
            let f = OpenOptions::new()
                .create(true)
                .append(true)
                .open(path)
                .map_err(|e| AppError::Io { source: e })?;
            Some(f)
        } else {
            None
        };

        Ok(Logger {
            log_file: Mutex::new(file),
            console_output: Mutex::new(true),
        })
    }

    pub fn log(&self, level: LogLevel, message: &str) -> Result<()> {
        let timestamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S");
        let formatted = format!("[{}] {} {}", timestamp, level, message);

        // Console'a yaz
        if *self.console_output.lock().unwrap() {
            match level {
                LogLevel::Error => eprintln!("{}", formatted),
                _ => println!("{}", formatted),
            }
        }

        // Dosyaya yaz
        if let Ok(mut file_lock) = self.log_file.lock() {
            if let Some(ref mut file) = *file_lock {
                writeln!(file, "{}", formatted).map_err(|e| AppError::Io { source: e })?;
                file.flush().map_err(|e| AppError::Io { source: e })?;
            }
        }

        Ok(())
    }

    pub fn info(&self, msg: &str) -> Result<()> {
        self.log(LogLevel::Info, msg)
    }

    pub fn error(&self, msg: &str) -> Result<()> {
        self.log(LogLevel::Error, msg)
    }

    pub fn warn(&self, msg: &str) -> Result<()> {
        self.log(LogLevel::Warn, msg)
    }

    pub fn debug(&self, msg: &str) -> Result<()> {
        self.log(LogLevel::Debug, msg)
    }
}
