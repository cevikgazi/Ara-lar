#[derive(Clone, Copy)]
pub enum Language {
    Turkish,
    English,
}

pub struct Translations {
    pub title: &'static str,
    pub subtitle: &'static str,
    pub source_dir: &'static str,
    pub not_selected: &'static str,
    pub browse: &'static str,
    pub extensions_label: &'static str,
    pub extensions_hint: &'static str,
    pub bind_button: &'static str,
    pub processing: &'static str,
    pub log_label: &'static str,
    pub ready: &'static str,
    pub done: &'static str,
    pub error_prefix: &'static str,
    pub processing_file: &'static str,
}

impl Language {
    pub fn get_translations(&self) -> Translations {
        match self {
            Language::Turkish => Translations {
                title: "⚒ ForgeBinder",
                subtitle: "Kod Tabanınızı LLM'ler için Birleştirin",
                source_dir: "Kaynak Dizin:",
                not_selected: "Seçilmedi...",
                browse: "📁 Gözat",
                extensions_label: "Uzantı Filtresi (virgülle ayırın):",
                extensions_hint: "Örn: .rs, .toml, .md (Boş bırakırsanız tüm dosyalar alınır)",
                bind_button: "🚀 Birleştir ve Kaydet",
                processing: "İşleniyor...",
                log_label: "İşlem Günlüğü:",
                ready: "Hazır.",
                done: "Tamamlandı!",
                error_prefix: "HATA:",
                processing_file: "İşleniyor:",
            },
            Language::English => Translations {
                title: "⚒ ForgeBinder",
                subtitle: "Bind Your Codebase for LLMs",
                source_dir: "Source Directory:",
                not_selected: "Not selected...",
                browse: "📁 Browse",
                extensions_label: "Extension Filter (comma separated):",
                extensions_hint: "e.g., .rs, .toml, .md (Leave empty to include all files)",
                bind_button: "🚀 Merge and Save",
                processing: "Processing...",
                log_label: "Process Log:",
                ready: "Ready.",
                done: "Completed!",
                error_prefix: "ERROR:",
                processing_file: "Processing:",
            },
        }
    }
}
