use crate::binder::{BinderConfigV2, ForgeBinder, BinderStats};
use crate::config::{ConfigManager, OutputFormat, Preset};
use crate::i18n::Language;
use eframe::egui;
use std::path::PathBuf;
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};

pub struct ForgeBinderApp {
    input_dir: Option<PathBuf>,
    output_path: Option<PathBuf>,
    item_selection: Vec<(String, bool)>,
    extensions: String,
    status_log: Vec<String>,
    is_processing: bool,
    progress_rx: Option<Receiver<String>>,
    _status_tx: Sender<String>,
    language: Language,
    initial_cwd: PathBuf,
    
    search_text: String,
    selected_preset: Option<String>,
    preset_name_input: String,
    show_statistics: bool,
    
    last_stats: Arc<Mutex<Option<BinderStats>>>,
    binder: Arc<ForgeBinder>,
}

impl ForgeBinderApp {
    pub fn new(_cc: &eframe::CreationContext<'_>, initial_path: Option<PathBuf>) -> Self {
        let (tx, _rx) = channel::<String>();
        let language = Language::Turkish;
        let trans = language.get_translations();
        
        // Önce FORGEBINDER_CWD değişkenine bak, yoksa mevcut dizini al
        let initial_cwd = std::env::var("FORGEBINDER_CWD").map(PathBuf::from)
            .unwrap_or_else(|_| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));

        let mut app = Self {
            input_dir: None,
            output_path: None,
            item_selection: Vec::new(),
            extensions: "rs, toml, md".to_string(),
            status_log: vec![trans.ready.to_string()],
            is_processing: false,
            progress_rx: None,
            _status_tx: tx,
            language,
            initial_cwd: initial_cwd.clone(),
            search_text: String::new(),
            selected_preset: None,
            preset_name_input: String::new(),
            show_statistics: true,
            last_stats: Arc::new(Mutex::new(None)),
            binder: Arc::new(ForgeBinder::new()),
        };

        // Eğer bir yol verilmişse, onu initial_cwd'ye göre çözümle
        if let Some(path) = initial_path {
            if path.is_relative() {
                app.set_input_dir(initial_cwd.join(path));
            } else {
                app.set_input_dir(path);
            }
        }

        app
    }

    fn set_input_dir(&mut self, path: PathBuf) {
        // Yolu normalize et (Canonicalize değil çünkü dosya olmayabilir, sadece sembolik düzeltme)
        let normalized_path = if path.exists() {
            path.canonicalize().unwrap_or(path)
        } else {
            path
        };

        self.input_dir = Some(normalized_path.clone());
        self.item_selection.clear();
        if let Ok(entries) = std::fs::read_dir(&normalized_path) {
            for entry in entries.flatten() {
                let name = entry.file_name().to_string_lossy().into_owned();
                if !name.starts_with('.') && name != "target" && name != "node_modules" {
                    self.item_selection.push((name, true));
                }
            }
            self.item_selection.sort_by(|a, b| a.0.cmp(&b.0));
        }
    }

    fn spawn_bind_worker(&mut self, config: BinderConfigV2) {
        let (tx, rx) = channel::<String>();
        self.progress_rx = Some(rx);
        self.is_processing = true;
        self.output_path = Some(config.output_file.clone());

        let binder = self.binder.clone();
        let lang_clone = self.language;
        let stats_container = self.last_stats.clone();

        std::thread::spawn(move || {
            match binder.bind_v2(config, tx.clone(), lang_clone) {
                Ok(stats) => {
                    if let Ok(mut lock) = stats_container.lock() {
                        *lock = Some(stats);
                    }
                    let _ = tx.send("✅ İşlem başarıyla tamamlandı!".to_string());
                }
                Err(e) => {
                    let _ = tx.send(format!("❌ HATA: {}", e));
                }
            }
        });
    }

    fn add_log(&mut self, msg: String) {
        self.status_log.push(msg);
        if self.status_log.len() > 100 { self.status_log.remove(0); }
    }

    fn apply_style(&self, ctx: &egui::Context) {
        let mut visuals = egui::Visuals::dark();
        visuals.widgets.noninteractive.bg_fill = egui::Color32::from_rgb(20, 20, 25);
        visuals.selection.bg_fill = egui::Color32::from_rgb(80, 100, 250);
        ctx.set_visuals(visuals);
    }
}

impl eframe::App for ForgeBinderApp {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.apply_style(ctx);
        let trans = self.language.get_translations();

        let mut messages = Vec::new();
        if let Some(ref rx) = self.progress_rx {
            while let Ok(msg) = rx.try_recv() { messages.push(msg); }
        }
        for msg in messages {
            self.add_log(msg.clone());
            if msg.contains("tamamlandı") || msg.contains("❌") { self.is_processing = false; }
        }

        egui::TopBottomPanel::top("header").show(ctx, |ui| {
            ui.add_space(10.0);
            ui.horizontal(|ui| {
                ui.heading(egui::RichText::new("⚒ ForgeBinder Pro").strong().size(22.0));
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.selectable_label(matches!(self.language, Language::English), "🇺🇸 EN").clicked() { self.language = Language::English; }
                    ui.separator();
                    if ui.selectable_label(matches!(self.language, Language::Turkish), "🇹🇷 TR").clicked() { self.language = Language::Turkish; }
                });
            });
            ui.add_space(10.0);
        });

        egui::SidePanel::left("sidebar").width_range(250.0..=350.0).show(ctx, |ui| {
            ui.add_space(10.0);
            ui.group(|ui| {
                ui.label(egui::RichText::new("📦 Profiller").strong());
                let presets = ConfigManager::list_presets().unwrap_or_default();
                let current = self.selected_preset.clone().unwrap_or_else(|| "Profil Seç...".into());
                egui::ComboBox::from_label("").selected_text(&current).width(ui.available_width()-10.0).show_ui(ui, |ui| {
                    for p in presets {
                        if ui.selectable_label(self.selected_preset.as_ref() == Some(&p), &p).clicked() {
                            if let Ok(Some(preset)) = ConfigManager::get_preset(&p) {
                                self.extensions = preset.extensions.join(", ");
                                self.selected_preset = Some(p);
                            }
                        }
                    }
                });
                ui.add_space(5.0);
                ui.horizontal(|ui| {
                    ui.add(egui::TextEdit::singleline(&mut self.preset_name_input).hint_text("Ad..."));
                    if ui.button("💾").clicked() && !self.preset_name_input.is_empty() {
                        let mut p = Preset::new(&self.preset_name_input);
                        p.extensions = self.extensions.split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
                        if ConfigManager::add_preset(p).is_ok() {
                            self.selected_preset = Some(self.preset_name_input.clone());
                            self.preset_name_input.clear();
                        }
                    }
                });
            });

            ui.add_space(10.0);
            ui.group(|ui| {
                ui.label(egui::RichText::new("⚙️ Ayarlar").strong());
                ui.label(trans.extensions_label);
                ui.text_edit_multiline(&mut self.extensions);
                ui.checkbox(&mut self.show_statistics, "📊 İstatistikleri Ekle");
            });

            if let Ok(lock) = self.last_stats.lock() {
                if let Some(stats) = lock.as_ref() {
                    ui.add_space(10.0);
                    ui.group(|ui| {
                        ui.label(egui::RichText::new("📈 Son Sonuç").strong());
                        ui.label(format!("Dosya: {}/{}", stats.files_processed, stats.total_files));
                        ui.label(format!("Satır: {}", stats.total_lines));
                        ui.label(format!("Boyut: {:.2} MB", stats.total_bytes as f64 / 1e6));
                    });
                }
            }
        });

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new(trans.source_dir).strong());
                let disp = self.input_dir.as_ref().map(|p| p.to_string_lossy().into_owned()).unwrap_or_else(|| trans.not_selected.to_string());
                ui.label(egui::RichText::new(&disp).monospace());
                if ui.button(trans.browse).clicked() {
                    if let Some(path) = rfd::FileDialog::new().set_directory(&self.initial_cwd).pick_folder() { self.set_input_dir(path); }
                }
            });

            ui.add_space(10.0);
            ui.horizontal(|ui| {
                ui.label("🔍");
                ui.add(egui::TextEdit::singleline(&mut self.search_text).hint_text("Ara..."));
            });

            egui::Frame::none().fill(egui::Color32::from_rgb(25, 25, 35)).rounding(4.0).show(ui, |ui| {
                let h = ui.available_height() - 220.0;
                egui::ScrollArea::vertical().max_height(h).show(ui, |ui| {
                    ui.set_width(ui.available_width());
                    for (name, selected) in self.item_selection.iter_mut() {
                        if self.search_text.is_empty() || name.to_lowercase().contains(&self.search_text.to_lowercase()) {
                            ui.checkbox(selected, name.as_str());
                        }
                    }
                });
            });

            ui.add_space(15.0);
            ui.horizontal(|ui| {
                let has_sel = self.item_selection.iter().any(|(_, s)| *s);
                let can_bind = self.input_dir.is_some() && has_sel && !self.is_processing;
                let btn = egui::Button::new(egui::RichText::new(if self.is_processing { trans.processing } else { trans.bind_button }).strong().size(18.0))
                    .min_size(egui::vec2(200.0, 40.0));
                
                if ui.add_enabled(can_bind, btn).clicked() {
                    if let Some(input) = &self.input_dir {
                        if let Some(output) = rfd::FileDialog::new().set_directory(&self.initial_cwd).set_file_name("codebase.md").save_file() {
                            let config = BinderConfigV2 {
                                input_dir: input.clone(),
                                output_file: output,
                                extensions: self.extensions.split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect(),
                                selected_items: self.item_selection.iter().filter(|(_, s)| *s).map(|(n, _)| n.clone()).collect(),
                                max_file_size_bytes: 5 * 1024 * 1024,
                                output_format: OutputFormat::Markdown,
                                include_stats: self.show_statistics,
                            };
                            self.spawn_bind_worker(config);
                        }
                    }
                }

                // Panoya Kopyala
                if let Some(path) = &self.output_path {
                    if !self.is_processing && ui.button(egui::RichText::new("📋 Panoya Kopyala").size(16.0)).clicked() {
                        if let Ok(content) = std::fs::read_to_string(path) {
                            ctx.output_mut(|o| o.copied_text = content);
                            self.add_log("✨ İçerik başarıyla panoya kopyalandı!".into());
                        }
                    }
                }

                if self.is_processing {
                    ui.spinner();
                    if ui.button("⏹").clicked() { self.binder.cancel(); }
                }
            });

            ui.add_space(10.0);
            egui::ScrollArea::vertical().stick_to_bottom(true).max_height(100.0).show(ui, |ui| {
                for log in &self.status_log { ui.label(egui::RichText::new(log).small().monospace()); }
            });
        });
        if self.is_processing { ctx.request_repaint(); }
    }
}
