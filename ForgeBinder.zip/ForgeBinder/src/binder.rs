use crate::config::OutputFormat;
use crate::error::{AppError, Result};
use crate::i18n::Language;
use ignore::WalkBuilder;
use std::fs::File;
use std::io::{BufWriter, Write, Read};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::Sender;
use std::sync::Arc;

pub struct BinderConfigV2 {
    pub input_dir: PathBuf,
    pub output_file: PathBuf,
    pub extensions: Vec<String>,
    pub selected_items: Vec<String>,
    pub max_file_size_bytes: u64,
    pub output_format: OutputFormat,
    pub include_stats: bool,
}

#[derive(Default, Clone)]
pub struct BinderStats {
    pub total_files: usize,
    pub total_lines: u64,
    pub total_bytes: u64,
    pub files_processed: usize,
    pub files_skipped: usize,
    pub errors: Vec<String>,
    pub language_breakdown: std::collections::HashMap<String, (usize, u64)>,
}

pub struct ForgeBinder {
    cancel_token: Arc<AtomicBool>,
}

impl ForgeBinder {
    pub fn new() -> Self {
        ForgeBinder {
            cancel_token: Arc::new(AtomicBool::new(false)),
        }
    }

    pub fn cancel(&self) {
        self.cancel_token.store(true, Ordering::Relaxed);
    }

    pub fn bind_v2(
        &self,
        config: BinderConfigV2,
        progress_tx: Sender<String>,
        lang: Language,
    ) -> Result<BinderStats> {
        let trans = lang.get_translations();
        let mut stats = BinderStats::default();

        let walker = WalkBuilder::new(&config.input_dir)
            .hidden(true)
            .git_ignore(true)
            .threads(std::thread::available_parallelism().map(|n| n.get()).unwrap_or(4))
            .build();

        let mut files_to_process = Vec::new();
        let _ = progress_tx.send(format!("🔍 {}", trans.processing));

        for result in walker {
            if self.cancel_token.load(Ordering::Relaxed) {
                return Err(AppError::ProcessingInterrupted { processed: stats.files_processed, total: stats.total_files });
            }

            match result {
                Ok(entry) => {
                    let path = entry.path();
                    if !Self::should_include_file(path, &config) {
                        continue;
                    }

                    if let Ok(metadata) = std::fs::metadata(path) {
                        if metadata.len() > config.max_file_size_bytes {
                            stats.files_skipped += 1;
                            continue;
                        }
                        files_to_process.push(path.to_path_buf());
                    }
                }
                Err(e) => {
                    stats.errors.push(format!("Tarama hatası: {}", e));
                }
            }
        }

        files_to_process.sort();
        stats.total_files = files_to_process.len();

        let output_file = File::create(&config.output_file).map_err(|e| AppError::Io { source: e })?;
        // Optimization: Large 512KB buffer for output
        let mut output = BufWriter::with_capacity(512 * 1024, output_file);

        Self::write_header(&mut output, &config, &stats, &lang)?;

        for (i, path) in files_to_process.iter().enumerate() {
            if self.cancel_token.load(Ordering::Relaxed) { break; }

            if (i + 1) % 10 == 0 || i + 1 == stats.total_files {
                let rel = path.strip_prefix(&config.input_dir).unwrap_or(path).to_string_lossy();
                let _ = progress_tx.send(format!("[{}/{}] {} {}", i + 1, stats.total_files, trans.processing_file, rel));
            }

            match Self::process_file_optimized(path, &config.input_dir, &mut output, &config.output_format, &mut stats) {
                Ok(_) => stats.files_processed += 1,
                Err(e) => {
                    stats.files_skipped += 1;
                    stats.errors.push(format!("{:?}: {}", path, e));
                }
            }
        }

        if config.include_stats {
            Self::write_footer(&mut output, &stats, &config.output_format, &lang)?;
        }

        output.flush().map_err(|e| AppError::Io { source: e })?;
        let _ = progress_tx.send(trans.done.to_string());
        Ok(stats)
    }

    fn should_include_file(path: &Path, config: &BinderConfigV2) -> bool {
        if !path.is_file() { return false; }
        let rel = path.strip_prefix(&config.input_dir).unwrap_or(path);
        let first = rel.components().next().map(|c| c.as_os_str().to_string_lossy().into_owned()).unwrap_or_default();
        if !config.selected_items.is_empty() && !config.selected_items.contains(&first) { return false; }

        let path_str = path.to_string_lossy();
        if ["/target/", "/.git/", "/node_modules/", "/dist/"].iter().any(|p| path_str.contains(p)) { return false; }

        if !config.extensions.is_empty() {
            let ext = path.extension().and_then(|s| s.to_str()).unwrap_or("");
            if !config.extensions.iter().any(|e| e.trim_start_matches('.') == ext) { return false; }
        }
        true
    }

    fn process_file_optimized(
        path: &Path,
        base_dir: &Path,
        output: &mut BufWriter<File>,
        format: &OutputFormat,
        stats: &mut BinderStats,
    ) -> Result<()> {
        if Self::is_binary_file(path)? { return Ok(()); }

        let rel = path.strip_prefix(base_dir).map_err(|_| AppError::InvalidPath { message: "Path mismatch".into() })?;
        let rel_str = rel.to_string_lossy();
        let mut file = File::open(path).map_err(|e| AppError::Io { source: e })?;
        let size = file.metadata().map(|m| m.len()).unwrap_or(0);
        let lines = Self::count_lines(path)?;

        stats.total_bytes += size;
        stats.total_lines += lines;
        let ext = path.extension().and_then(|s| s.to_str()).unwrap_or("unknown").to_string();
        stats.language_breakdown.entry(ext).and_modify(|(c, b)| { *c += 1; *b += size; }).or_insert((1, size));

        match format {
            OutputFormat::Xml => {
                writeln!(output, "<DOCUMENT filename=\"{}\" lines=\"{}\" size=\"{}\">", rel_str, lines, size).map_err(|e| AppError::Io { source: e })?;
                std::io::copy(&mut file, output).map_err(|e| AppError::Io { source: e })?;
                writeln!(output, "\n</DOCUMENT>\n").map_err(|e| AppError::Io { source: e })?;
            }
            OutputFormat::Markdown => {
                writeln!(output, "## {} ({} lines)\n```", rel_str, lines).map_err(|e| AppError::Io { source: e })?;
                std::io::copy(&mut file, output).map_err(|e| AppError::Io { source: e })?;
                writeln!(output, "\n```\n").map_err(|e| AppError::Io { source: e })?;
            }
            OutputFormat::Json | OutputFormat::JsonLines => {
                if size > 1_000_000 {
                    writeln!(output, "{{\"file\": \"{}\", \"content\": \"[Too Large]\"}}", rel_str).map_err(|e| AppError::Io { source: e })?;
                } else {
                    let content = std::fs::read_to_string(path).map_err(|e| AppError::Io { source: e })?;
                    let json = serde_json::json!({ "file": rel_str, "content": content });
                    writeln!(output, "{}", json).map_err(|e| AppError::Io { source: e })?;
                }
            }
            _ => {}
        }
        Ok(())
    }

    fn write_header(output: &mut BufWriter<File>, config: &BinderConfigV2, stats: &BinderStats, _lang: &Language) -> Result<()> {
        match config.output_format {
            OutputFormat::Markdown => {
                writeln!(output, "# Codebase Context\n**Files:** {}\n**Size:** {:.2} MB\n", stats.total_files, stats.total_bytes as f64 / 1e6).ok();
            }
            _ => {}
        }
        Ok(())
    }

    fn write_footer(output: &mut BufWriter<File>, stats: &BinderStats, format: &OutputFormat, _lang: &Language) -> Result<()> {
        if let OutputFormat::Markdown = format {
            writeln!(output, "\n## Final Stats\n- Processed: {}\n- Lines: {}\n", stats.files_processed, stats.total_lines).ok();
        }
        Ok(())
    }

    pub fn is_binary_file(path: &Path) -> Result<bool> {
        let mut file = File::open(path).map_err(|e| AppError::Io { source: e })?;
        let mut buf = [0u8; 1024];
        let n = file.read(&mut buf).map_err(|e| AppError::Io { source: e })?;
        Ok(buf[..n].iter().any(|&b| b == 0))
    }

    fn count_lines(path: &Path) -> Result<u64> {
        let file = File::open(path).map_err(|e| AppError::Io { source: e })?;
        let reader = std::io::BufReader::new(file);
        Ok(reader.bytes().filter(|b| matches!(b, Ok(b'\n'))).count() as u64)
    }
}
