use crate::config::OutputFormat;
use crate::binder::{ForgeBinder, BinderConfigV2};
use crate::error::Result;
use crate::i18n::Language;
use clap::{Parser, Subcommand, Args};
use std::path::PathBuf;
use std::sync::mpsc;

#[derive(Parser, Debug)]
#[command(name = "forgebinder", about = "ForgeBinder Pro - Advanced Codebase Aggregator", version = "2.0.0")]
pub struct CliArgs {
    #[command(subcommand)]
    pub command: Option<Commands>,

    #[arg(value_name = "PATH")]
    pub path: Option<PathBuf>,

    #[arg(short, long)]
    pub verbose: bool,
}

#[derive(Subcommand, Debug)]
pub enum Commands {
    Bind(BindArgs),
    Preset(PresetArgs),
    Config(ConfigArgs),
}

#[derive(Args, Debug)]
pub struct BindArgs {
    #[arg(short, long, default_value = ".")]
    pub input: PathBuf,

    #[arg(short, long, default_value = "codebase_context.md")]
    pub output: PathBuf,

    #[arg(short, long, default_value = "rs,toml,md")]
    pub extensions: String,

    #[arg(short = 'f', long, default_value = "markdown")]
    pub format: String,

    #[arg(short = 's', long, default_value_t = true)]
    pub stats: bool,

    #[arg(short = 'm', long, default_value = "5")]
    pub max_size: u64,

    #[arg(short, long, default_value_t = false)]
    pub verbose: bool,
}

#[derive(Args, Debug)]
pub struct PresetArgs {
    #[command(subcommand)]
    pub command: PresetCommands,
}

#[derive(Subcommand, Debug)]
pub enum PresetCommands {
    List,
    Delete { name: String },
}

#[derive(Args, Debug)]
pub struct ConfigArgs {
    #[command(subcommand)]
    pub command: ConfigCommands,
}

#[derive(Subcommand, Debug)]
pub enum ConfigCommands {
    Show,
}

pub async fn run_cli_sync(args: CliArgs) -> Result<()> {
    match args.command {
        Some(Commands::Bind(bind_args)) => {
            handle_bind(bind_args).await?;
        }
        Some(Commands::Preset(preset_args)) => {
            handle_preset(preset_args.command)?;
        }
        Some(Commands::Config(config_args)) => {
            handle_config(config_args.command)?;
        }
        None => {}
    }
    Ok(())
}

async fn handle_bind(args: BindArgs) -> Result<()> {
    let binder = ForgeBinder::new();
    let (tx, rx) = mpsc::channel::<String>();
    
    let format = match args.format.to_lowercase().as_str() {
        "json" => OutputFormat::Json,
        "markdown" | "md" => OutputFormat::Markdown,
        "html" => OutputFormat::Html,
        "jsonl" | "jsonlines" => OutputFormat::JsonLines,
        _ => OutputFormat::Xml,
    };

    let config = BinderConfigV2 {
        input_dir: args.input.clone(),
        output_file: args.output.clone(),
        extensions: args.extensions.split(',').map(|s| s.trim().trim_start_matches('.').to_string()).filter(|s| !s.is_empty()).collect(),
        selected_items: Vec::new(),
        max_file_size_bytes: args.max_size * 1024 * 1024,
        output_format: format,
        include_stats: args.stats,
    };

    let verbose = args.verbose;
    std::thread::spawn(move || {
        while let Ok(msg) = rx.recv() {
            if verbose || msg.starts_with("✅") || msg.contains("İstatistikler") {
                println!("{}", msg);
            }
        }
    });

    let stats = binder.bind_v2(config, tx, Language::Turkish)?;
    println!("\n✅ İşlem başarıyla tamamlandı! ({} dosya işlendi)", stats.files_processed);
    Ok(())
}

fn handle_preset(cmd: PresetCommands) -> Result<()> {
    use crate::config::ConfigManager;
    if let PresetCommands::List = cmd {
        let presets = ConfigManager::list_presets()?;
        println!("📦 Kaydedilmiş Profiller:");
        for p in presets { println!("  • {}", p); }
    }
    Ok(())
}

fn handle_config(_cmd: ConfigCommands) -> Result<()> {
    println!("⚙️  Yapılandırma gösterimi aktif.");
    Ok(())
}
