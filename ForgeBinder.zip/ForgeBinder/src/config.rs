use crate::error::{AppError, Result};
use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Preset {
    pub name: String,
    pub description: Option<String>,
    pub extensions: Vec<String>,
    pub exclude_dirs: Vec<String>,
    pub max_file_size_mb: u32,
    pub follow_gitignore: bool,
    pub output_format: OutputFormat,
    pub created_at: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum OutputFormat {
    Xml,
    Json,
    Markdown,
    Html,
    JsonLines,
}

impl Default for OutputFormat {
    fn default() -> Self {
        OutputFormat::Xml
    }
}

impl std::fmt::Display for OutputFormat {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            OutputFormat::Xml => write!(f, "XML (Default)"),
            OutputFormat::Json => write!(f, "JSON"),
            OutputFormat::Markdown => write!(f, "Markdown"),
            OutputFormat::Html => write!(f, "HTML"),
            OutputFormat::JsonLines => write!(f, "JSON Lines"),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    pub presets: Vec<Preset>,
    pub last_used_preset: Option<String>,
    pub theme: Theme,
    pub auto_save_interval_secs: u32,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub enum Theme {
    Dark,
    Light,
    Auto,
}

impl Default for Config {
    fn default() -> Self {
        Config {
            presets: vec![
                Preset::rust_default(),
                Preset::typescript_default(),
                Preset::documentation_default(),
            ],
            last_used_preset: None,
            theme: Theme::Dark,
            auto_save_interval_secs: 60,
        }
    }
}

impl Preset {
    pub fn new(name: impl Into<String>) -> Self {
        Preset {
            name: name.into(),
            description: None,
            extensions: vec![],
            exclude_dirs: vec![
                "target".to_string(),
                ".git".to_string(),
                "node_modules".to_string(),
                ".next".to_string(),
                "dist".to_string(),
            ],
            max_file_size_mb: 1,
            follow_gitignore: true,
            output_format: OutputFormat::Xml,
            created_at: chrono::Local::now().to_rfc3339(),
        }
    }

    /// Rust Projesi - Default
    pub fn rust_default() -> Self {
        Preset {
            name: "🦀 Rust Project (Full)".to_string(),
            description: Some("Tüm Rust dosyaları + config".to_string()),
            extensions: vec![".rs".to_string(), ".toml".to_string(), ".md".to_string()],
            exclude_dirs: vec!["target".to_string(), ".git".to_string(), "dist".to_string()],
            max_file_size_mb: 1,
            follow_gitignore: true,
            output_format: OutputFormat::Xml,
            created_at: chrono::Local::now().to_rfc3339(),
        }
    }

    /// TypeScript/JavaScript - Default
    pub fn typescript_default() -> Self {
        Preset {
            name: "📘 TypeScript/React".to_string(),
            description: Some("Web frontend (TS/TSX/JS/JSX/CSS)".to_string()),
            extensions: vec![
                ".ts".to_string(),
                ".tsx".to_string(),
                ".js".to_string(),
                ".jsx".to_string(),
                ".css".to_string(),
                ".json".to_string(),
            ],
            exclude_dirs: vec![
                "node_modules".to_string(),
                "dist".to_string(),
                "build".to_string(),
                ".next".to_string(),
                "coverage".to_string(),
            ],
            max_file_size_mb: 2,
            follow_gitignore: true,
            output_format: OutputFormat::Markdown,
            created_at: chrono::Local::now().to_rfc3339(),
        }
    }

    /// Dokümantasyon - Default
    pub fn documentation_default() -> Self {
        Preset {
            name: "📚 Documentation Only".to_string(),
            description: Some("Sadece .md, .txt, .mdx dosyaları".to_string()),
            extensions: vec![".md".to_string(), ".mdx".to_string(), ".txt".to_string()],
            exclude_dirs: vec![],
            max_file_size_mb: 5,
            follow_gitignore: true,
            output_format: OutputFormat::Markdown,
            created_at: chrono::Local::now().to_rfc3339(),
        }
    }
}

pub struct ConfigManager;

impl ConfigManager {
    fn config_dir() -> Result<PathBuf> {
        let base = dirs::config_dir().ok_or(AppError::InvalidPath {
            message: "Config dizini bulunamadı".to_string(),
        })?;
        let config_dir = base.join("forgebinder");

        if !config_dir.exists() {
            fs::create_dir_all(&config_dir).map_err(|e| AppError::Io { source: e })?;
        }

        Ok(config_dir)
    }

    pub fn config_file() -> Result<PathBuf> {
        Ok(Self::config_dir()?.join("config.toml"))
    }

    pub fn presets_file() -> Result<PathBuf> {
        Ok(Self::config_dir()?.join("presets.json"))
    }

    pub fn load() -> Result<Config> {
        let config_file = Self::config_file()?;

        if !config_file.exists() {
            let default_config = Config::default();
            Self::save(&default_config)?;
            return Ok(default_config);
        }

        let content = fs::read_to_string(&config_file).map_err(|e| AppError::Io { source: e })?;

        toml::from_str(&content)
            .map_err(|e| AppError::InvalidPath { message: format!("Config parse hatası: {}", e) })
    }

    pub fn save(config: &Config) -> Result<()> {
        let config_file = Self::config_file()?;
        let toml_string = toml::to_string_pretty(config)
            .map_err(|e| AppError::InvalidPath { message: format!("Config serialize hatası: {}", e) })?;

        fs::write(&config_file, toml_string).map_err(|e| AppError::Io { source: e })?;

        Ok(())
    }

    pub fn add_preset(preset: Preset) -> Result<()> {
        let mut config = Self::load()?;

        // Duplicate check
        if config.presets.iter().any(|p| p.name == preset.name) {
            return Err(AppError::InvalidPath {
                message: format!("'{}' adında preset zaten var", preset.name),
            });
        }

        config.presets.push(preset);
        Self::save(&config)?;
        Ok(())
    }

    pub fn remove_preset(name: &str) -> Result<()> {
        let mut config = Self::load()?;

        // Built-in preset'leri silmeye izin verme
        if name.starts_with("🦀") || name.starts_with("📘") || name.starts_with("📚") {
            return Err(AppError::InvalidPath {
                message: "Built-in preset'ler silinemez".to_string(),
            });
        }

        config.presets.retain(|p| p.name != name);
        Self::save(&config)?;
        Ok(())
    }

    pub fn get_preset(name: &str) -> Result<Option<Preset>> {
        let config = Self::load()?;
        Ok(config.presets.into_iter().find(|p| p.name == name))
    }

    pub fn list_presets() -> Result<Vec<String>> {
        let config = Self::load()?;
        Ok(config.presets.iter().map(|p| p.name.clone()).collect())
    }
}
