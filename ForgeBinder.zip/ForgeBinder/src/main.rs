use forgebinder::app;
use forgebinder::cli_enhanced;
use eframe::egui;
use clap::Parser;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cli_args = cli_enhanced::CliArgs::parse();

    // CLI mode vs GUI mode
    if cli_args.command.is_some() {
        // CLI Mode
        cli_enhanced::run_cli_sync(cli_args).await?;
        return Ok(());
    }

    // GUI Mode (default)
    let initial_path = cli_args.path;

    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1000.0, 700.0])
            .with_min_inner_size([800.0, 600.0]),
        ..Default::default()
    };

    eframe::run_native(
        "ForgeBinder Pro",
        options,
        Box::new(|cc| {
            Box::new(app::ForgeBinderApp::new(cc, initial_path)) as Box<dyn eframe::App>
        }),
    )
    .map_err(|e| Box::new(e) as Box<dyn std::error::Error>)
}
