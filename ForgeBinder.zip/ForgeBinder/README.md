# ⚒ ForgeBinder Pro

[![Rust](https://img.shields.io/badge/rust-stable-brightgreen.svg)](https://www.rust-lang.org/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/platform-linux%20%7C%20macos-lightgrey.svg)](README.md)

**ForgeBinder**, geliştiriciler ve AI asistanları (ChatGPT, Claude, Gemini) için tasarlanmış, yüksek performanslı bir codebase birleştirme aracıdır. Dev projeleri saniyeler içinde analiz edilebilir tek bir bağlam dosyasına dönüştürür.

---

## 🚀 Öne Çıkan Özellikler

- **⚡ Yıldırım Hızında:** Streaming I/O ve çok çekirdekli tarama motoru ile binlerce dosyayı saniyeler içinde işler.
- **🖥 Çift Mod:** Hem şık bir **GUI** (arayüz) hem de güçlü bir **CLI** (komut satırı) aracıdır.
- **📋 Panoya Kopyala:** Birleştirme sonrası tek tıkla tüm içeriği panoya kopyalayarak AI'ya anında aktarım sağlar.
- **📦 Profil Yönetimi:** Rust, Go, TypeScript gibi farklı teknolojiler için özelleştirilmiş tarama profilleri.
- **📊 Akıllı İstatistikler:** Kod tabanınızın dil dağılımını, satır sayılarını ve boyutunu anında raporlar.
- **🔍 Gelişmiş Filtreleme:** Akıllı ignore (git, node_modules) yönetimi ve dosya boyutu limitleri.
- **🌈 Çoklu Format:** Markdown, XML, JSON ve JSONL çıktı desteği.

---

## 📦 Kurulum

### 1. Standart Kurulum (Tüm Linux Dağıtımları)

```bash
git clone https://github.com/kullanici/forgebinder.git
cd forgebinder
chmod +x install.sh
./install.sh
```

### 2. NixOS / Devbox Kullanıcıları İçin

NixOS üzerinde kütüphane hatalarını önlemek için kurulumu Devbox ile başlatın:

```bash
devbox run ./install.sh
```

Kurulumdan sonra `forgebinder` komutu `~/.cargo/bin` dizinine eklenecektir.

---

## 🛠 Kullanım

### Komut Satırı (CLI)

```bash
# Mevcut dizini (.) Markdown olarak birleştir
forgebinder .

# Belirli bir dizini belirli bir formatta birleştir
forgebinder bind --input ./src --output context.xml --format xml
```

### Grafik Arayüz (GUI)

Sadece `forgebinder` yazarak arayüzü başlatın. Projenizi seçtikten sonra **"📋 Panoya Kopyala"** butonunu kullanarak sonucu anında AI asistanınıza yapıştırabilirsiniz.

---

## 🤝 Katkıda Bulunun

Fikirleriniz ve katkılarınız bizim için değerlidir! Lütfen Pull Request açmaktan çekinmeyin.

---

## 📜 Lisans

Bu proje **MIT** lisansı altında lisanslanmıştır.

---

<p align="center">
  <i>ForgeBinder ile kodunuzun bağlamını AI'ya saniyeler içinde aktarın.</i>
</p>
