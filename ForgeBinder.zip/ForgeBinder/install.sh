#!/usr/bin/env bash

# ForgeBinder Global Installer (NixOS/Devbox Wrapper - PWD Fixed)
set -e

echo "⚒ ForgeBinder derleniyor..."
cargo build --release

BIN_NAME="forgebinder"
PROJECT_DIR=$(pwd)
REAL_BIN_PATH="$PROJECT_DIR/target/release/$BIN_NAME"
TARGET_DIR="$HOME/.cargo/bin"
WRAPPER_PATH="$TARGET_DIR/$BIN_NAME"

# Dizin yoksa oluştur
mkdir -p "$TARGET_DIR"

echo "🚀 NixOS/Devbox uyumlu sarmalayıcı (PWD desteği ile) güncelleniyor: $WRAPPER_PATH"

# Düzeltilmiş Wrapper: Mevcut PWD bilgisini FORGEBINDER_CWD olarak aktarır
cat <<EOF > "$WRAPPER_PATH"
#!/usr/bin/env bash
# ForgeBinder NixOS Wrapper
# Mevcut konumu sakla
export FORGEBINDER_CWD=\$(pwd)
# Proje dizinine git ve devbox ile çalıştır
cd "$PROJECT_DIR" && exec devbox run -- "$REAL_BIN_PATH" "\$@"
EOF

chmod +x "$WRAPPER_PATH"

echo "🎉 Kurulum başarıyla tamamlandı!"
echo "Artık 'forgebinder .' dediğinizde, tam olarak bulunduğunuz dizini referans alacaktır."
